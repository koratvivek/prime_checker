# Prime Checker Library

A simple Python library to check if a number is prime.

## Installation

```bash
pip install prime_checker
