from .core import is_prime

__all__ = ["is_prime"]
